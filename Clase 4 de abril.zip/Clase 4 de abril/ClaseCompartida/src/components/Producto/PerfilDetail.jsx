import React from 'react'

const PerfilDetail = () => {
  return (
    <div>PerfilDetail</div>
  )
}

export default PerfilDetail